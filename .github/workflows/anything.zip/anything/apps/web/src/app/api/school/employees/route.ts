import sql from '@/app/api/utils/sql';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get('type');
  const search = searchParams.get('search');

  try {
    let query = 'SELECT * FROM employees WHERE 1=1';
    const params: any[] = [];

    if (type && type !== 'All') {
      params.push(type);
      query += ` AND type = $${params.length}`;
    }

    if (search) {
      params.push(`%${search.toLowerCase()}%`);
      query += ` AND LOWER(full_name) LIKE $${params.length}`;
    }

    query += ' ORDER BY full_name ASC';

    const employees = await sql(query, params);
    return Response.json(employees);
  } catch (error) {
    console.error('Fetch employees error:', error);
    return Response.json({ error: 'Failed to fetch employees' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const { full_name, role, phone, type, photo_url } = await request.json();
    const result = await sql`
      INSERT INTO employees (full_name, role, phone, type, photo_url)
      VALUES (${full_name}, ${role}, ${phone}, ${type}, ${photo_url || null})
      RETURNING *
    `;
    return Response.json(result[0]);
  } catch (error) {
    console.error('Create employee error:', error);
    return Response.json({ error: 'Failed to create employee' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const { id, full_name, role, phone, type, photo_url } = await request.json();
    const result = await sql`
      UPDATE employees 
      SET full_name = ${full_name}, role = ${role}, phone = ${phone}, type = ${type}, photo_url = ${photo_url || null}
      WHERE id = ${id}
      RETURNING *
    `;
    return Response.json(result[0]);
  } catch (error) {
    console.error('Update employee error:', error);
    return Response.json({ error: 'Failed to update employee' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get('id');
  await sql`DELETE FROM employees WHERE id = ${id}`;
  return Response.json({ success: true });
}
