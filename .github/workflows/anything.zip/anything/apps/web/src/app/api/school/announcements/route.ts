import sql from '@/app/api/utils/sql';

export async function GET() {
  try {
    const announcements = await sql`SELECT * FROM announcements ORDER BY created_at DESC`;
    return Response.json(announcements);
  } catch (error) {
    return Response.json({ error: 'Failed to fetch announcements' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const { title, content, priority } = await request.json();
    const result = await sql`
      INSERT INTO announcements (title, content, priority)
      VALUES (${title}, ${content}, ${priority})
      RETURNING *
    `;
    return Response.json(result[0]);
  } catch (error) {
    return Response.json({ error: 'Failed to create announcement' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const { id, title, content, priority } = await request.json();
    const result = await sql`
      UPDATE announcements 
      SET title = ${title}, content = ${content}, priority = ${priority}
      WHERE id = ${id}
      RETURNING *
    `;
    return Response.json(result[0]);
  } catch (error) {
    return Response.json({ error: 'Failed to update announcement' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get('id');
  await sql`DELETE FROM announcements WHERE id = ${id}`;
  return Response.json({ success: true });
}
