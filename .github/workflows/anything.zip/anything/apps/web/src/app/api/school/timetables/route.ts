import sql from '@/app/api/utils/sql';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const targetType = searchParams.get('targetType');
  const targetName = searchParams.get('targetName');

  try {
    let query = 'SELECT * FROM timetables WHERE 1=1';
    const params: any[] = [];

    if (targetType) {
      params.push(targetType);
      query += ` AND target_type = $${params.length}`;
    }

    if (targetName) {
      params.push(targetName);
      query += ` AND target_name = $${params.length}`;
    }

    query += ' ORDER BY uploaded_at DESC';

    const timetables = await sql(query, params);
    return Response.json(timetables);
  } catch (error) {
    return Response.json({ error: 'Failed to fetch timetables' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const { target_name, target_type, file_url, file_name } = await request.json();

    // Replace old timetable for the same target
    await sql`DELETE FROM timetables WHERE target_name = ${target_name} AND target_type = ${target_type}`;

    const result = await sql`
      INSERT INTO timetables (target_name, target_type, file_url, file_name)
      VALUES (${target_name}, ${target_type}, ${file_url}, ${file_name})
      RETURNING *
    `;
    return Response.json(result[0]);
  } catch (error) {
    return Response.json({ error: 'Failed to upload timetable' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get('id');
  await sql`DELETE FROM timetables WHERE id = ${id}`;
  return Response.json({ success: true });
}
