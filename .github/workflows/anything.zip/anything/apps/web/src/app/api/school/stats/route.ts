import sql from '@/app/api/utils/sql';

export async function GET() {
  try {
    const [studentsCount] = await sql`SELECT COUNT(*)::int as count FROM students`;
    const [employeesCount] = await sql`SELECT COUNT(*)::int as count FROM employees`;
    const [examsCount] =
      await sql`SELECT COUNT(*)::int as count FROM exams WHERE exam_date >= CURRENT_DATE`;
    const [announcementsCount] = await sql`SELECT COUNT(*)::int as count FROM announcements`;

    const studentsPerClass = await sql`
      SELECT class_name, COUNT(*)::int as count 
      FROM students 
      GROUP BY class_name 
      ORDER BY class_name
    `;

    const employeesByRole = await sql`
      SELECT type, COUNT(*)::int as count 
      FROM employees 
      GROUP BY type
    `;

    return Response.json({
      totals: {
        students: studentsCount.count,
        employees: employeesCount.count,
        exams: examsCount.count,
        announcements: announcementsCount.count,
      },
      studentsPerClass,
      employeesByRole,
    });
  } catch (error) {
    console.error('Stats error:', error);
    return Response.json({ error: 'Failed to fetch stats' }, { status: 500 });
  }
}
