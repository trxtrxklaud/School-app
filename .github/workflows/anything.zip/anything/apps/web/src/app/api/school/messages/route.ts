import sql from '@/app/api/utils/sql';

export async function GET() {
  try {
    const messages = await sql`SELECT * FROM messages ORDER BY created_at DESC`;
    return Response.json(messages);
  } catch (error) {
    return Response.json({ error: 'Failed to fetch messages' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const { sender_name, subject, message } = await request.json();
    const result = await sql`
      INSERT INTO messages (sender_name, subject, message)
      VALUES (${sender_name}, ${subject}, ${message})
      RETURNING *
    `;
    return Response.json(result[0]);
  } catch (error) {
    return Response.json({ error: 'Failed to create message' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const { id, is_read } = await request.json();
    const result = await sql`
      UPDATE messages 
      SET is_read = ${is_read}
      WHERE id = ${id}
      RETURNING *
    `;
    return Response.json(result[0]);
  } catch (error) {
    return Response.json({ error: 'Failed to update message' }, { status: 500 });
  }
}
