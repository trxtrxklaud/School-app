import sql from '@/app/api/utils/sql';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const className = searchParams.get('className');
  const search = searchParams.get('search');

  try {
    let query = 'SELECT * FROM students WHERE 1=1';
    const params: any[] = [];

    if (className) {
      params.push(className);
      query += ` AND class_name = $${params.length}`;
    }

    if (search) {
      params.push(`%${search.toLowerCase()}%`);
      query += ` AND LOWER(full_name) LIKE $${params.length}`;
    }

    query += ' ORDER BY full_name ASC';

    const students = await sql(query, params);
    return Response.json(students);
  } catch (error) {
    console.error('Fetch students error:', error);
    return Response.json({ error: 'Failed to fetch students' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();

    // Check if it's a bulk import
    if (Array.isArray(body)) {
      const results = [];
      for (const student of body) {
        const result = await sql`
          INSERT INTO students (full_name, class_name, birth_date, parent_name, parent_phone, notes)
          VALUES (${student.full_name}, ${student.class}, ${student.birth_date || null}, ${student.parent_name}, ${student.parent_phone}, ${student.notes || ''})
          RETURNING *
        `;
        results.push(result[0]);
      }
      return Response.json(results);
    }

    const { full_name, class_name, birth_date, parent_name, parent_phone, notes } = body;
    const result = await sql`
      INSERT INTO students (full_name, class_name, birth_date, parent_name, parent_phone, notes)
      VALUES (${full_name}, ${class_name}, ${birth_date || null}, ${parent_name}, ${parent_phone}, ${notes || ''})
      RETURNING *
    `;
    return Response.json(result[0]);
  } catch (error) {
    console.error('Create student error:', error);
    return Response.json({ error: 'Failed to create student' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, full_name, class_name, birth_date, parent_name, parent_phone, notes } = body;

    const result = await sql`
      UPDATE students 
      SET full_name = ${full_name}, 
          class_name = ${class_name}, 
          birth_date = ${birth_date || null}, 
          parent_name = ${parent_name}, 
          parent_phone = ${parent_phone}, 
          notes = ${notes || ''}
      WHERE id = ${id}
      RETURNING *
    `;

    if (result.length === 0) {
      return Response.json({ error: 'Student not found' }, { status: 404 });
    }

    return Response.json(result[0]);
  } catch (error) {
    console.error('Update student error:', error);
    return Response.json({ error: 'Failed to update student' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get('id');

  if (!id) {
    return Response.json({ error: 'ID is required' }, { status: 400 });
  }

  try {
    await sql`DELETE FROM students WHERE id = ${id}`;
    return Response.json({ success: true });
  } catch (error) {
    console.error('Delete student error:', error);
    return Response.json({ error: 'Failed to delete student' }, { status: 500 });
  }
}
