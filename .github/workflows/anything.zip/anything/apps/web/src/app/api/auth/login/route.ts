import { hash, verify } from 'argon2';
import sql from '@/app/api/utils/sql';

export async function POST(request: Request) {
  try {
    const { username, password } = await request.json();

    const users = await sql`SELECT * FROM users WHERE username = ${username}`;

    if (users.length === 0) {
      // Demo credentials fallback
      const demoUsers: Record<string, { password: string; role: string; full_name: string }> = {
        محمد: { password: 'ريمحمدوني', role: 'admin', full_name: 'محمد' },
        prof: { password: 'prof123', role: 'teacher', full_name: 'Professeur CP' },
      };

      if (demoUsers[username] && demoUsers[username].password === password) {
        const user = demoUsers[username];
        const hashedPassword = await hash(password);
        await sql`INSERT INTO users (username, password_hash, role, full_name) VALUES (${username}, ${hashedPassword}, ${user.role}, ${user.full_name}) ON CONFLICT (username) DO NOTHING`;
        return Response.json({
          success: true,
          user: { username, role: user.role, full_name: user.full_name },
        });
      }
      return Response.json({ success: false, error: 'Utilisateur non trouvé' }, { status: 401 });
    }

    const user = users[0];
    let isValid = false;
    try {
      isValid = await verify(user.password_hash, password);
    } catch (e) {
      // Fallback for legacy/bad hashes
      const demoPasswords: Record<string, string> = {
        محمد: 'ريمحمدوني',
        admin: 'providence2024',
        prof: 'prof123',
      };
      if (demoPasswords[username] === password) {
        isValid = true;
        const newHash = await hash(password);
        await sql`UPDATE users SET password_hash = ${newHash} WHERE id = ${user.id}`;
      }
    }

    if (isValid) {
      return Response.json({
        success: true,
        user: { username: user.username, role: user.role, full_name: user.full_name },
      });
    }

    return Response.json({ success: false, error: 'Mot de passe incorrect' }, { status: 401 });
  } catch (error) {
    console.error('Login error:', error);
    return Response.json({ success: false, error: 'Erreur serveur' }, { status: 500 });
  }
}
