import sql from '@/app/api/utils/sql';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const session = searchParams.get('session');

  try {
    let query = 'SELECT * FROM exams WHERE 1=1';
    const params: any[] = [];

    if (session && session !== 'All') {
      params.push(session);
      query += ` AND session = $${params.length}`;
    }

    query += ' ORDER BY exam_date ASC, exam_time ASC';

    const exams = await sql(query, params);
    return Response.json(exams);
  } catch (error) {
    return Response.json({ error: 'Failed to fetch exams' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const { subject, exam_date, exam_time, room, supervisor, session } = await request.json();
    const result = await sql`
      INSERT INTO exams (subject, exam_date, exam_time, room, supervisor, session)
      VALUES (${subject}, ${exam_date}, ${exam_time}, ${room}, ${supervisor}, ${session})
      RETURNING *
    `;
    return Response.json(result[0]);
  } catch (error) {
    return Response.json({ error: 'Failed to create exam' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const { id, subject, exam_date, exam_time, room, supervisor, session } = await request.json();
    const result = await sql`
      UPDATE exams 
      SET subject = ${subject}, exam_date = ${exam_date}, exam_time = ${exam_time}, room = ${room}, supervisor = ${supervisor}, session = ${session}
      WHERE id = ${id}
      RETURNING *
    `;
    return Response.json(result[0]);
  } catch (error) {
    return Response.json({ error: 'Failed to update exam' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get('id');
  await sql`DELETE FROM exams WHERE id = ${id}`;
  return Response.json({ success: true });
}
