import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  ScrollView,
  Platform,
} from 'react-native';
import { useSchoolAuthStore } from '@/utils/schoolAuthStore';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useI18n } from '@/utils/i18n';
import KeyboardAvoidingAnimatedView from '@/components/KeyboardAvoidingAnimatedView';

const PRIMARY_BLUE = '#1a237e';
const GOLD = '#f9a825';

export default function LoginScreen() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const { login } = useSchoolAuthStore();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { t, language, setLanguage, isRTL } = useI18n();

  const rtl = isRTL;

  const handleLogin = async () => {
    if (!username.trim() || !password.trim()) {
      Alert.alert(t('error'), rtl ? 'يرجى ملء جميع الحقول' : 'Veuillez remplir tous les champs');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${process.env.EXPO_PUBLIC_BASE_URL}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username.trim(), password }),
      });

      const data = await response.json();

      if (data.success) {
        login(data.user);
        router.replace('/(tabs)' as any);
      } else {
        Alert.alert(t('error'), data.error || t('loginError'));
      }
    } catch {
      Alert.alert(t('error'), rtl ? 'تعذر الاتصال بالخادم' : 'Impossible de contacter le serveur');
    } finally {
      setLoading(false);
    }
  };

  const inputStyle = () => ({
    flex: 1,
    height: 54,
    paddingHorizontal: 16,
    fontSize: 16,
    color: PRIMARY_BLUE,
    textAlign: rtl ? ('right' as const) : ('left' as const),
    writingDirection: rtl ? ('rtl' as const) : ('ltr' as const),
  });

  return (
    <KeyboardAvoidingAnimatedView
      style={{ flex: 1, backgroundColor: PRIMARY_BLUE }}
      behavior="padding"
    >
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        keyboardShouldPersistTaps="handled"
        bounces={false}
        showsVerticalScrollIndicator={false}
      >
        {/* Hero Section */}
        <View
          style={{
            backgroundColor: PRIMARY_BLUE,
            paddingTop: insets.top + 24,
            paddingBottom: 48,
            paddingHorizontal: 28,
            alignItems: 'center',
          }}
        >
          {/* Language toggle */}
          <TouchableOpacity
            onPress={() => setLanguage(language === 'fr' ? 'ar' : 'fr')}
            style={{
              position: 'absolute',
              top: insets.top + 16,
              right: 20,
              backgroundColor: 'rgba(255,255,255,0.12)',
              paddingHorizontal: 14,
              paddingVertical: 7,
              borderRadius: 20,
              borderWidth: 1,
              borderColor: 'rgba(255,255,255,0.25)',
            }}
          >
            <Text style={{ color: '#fff', fontSize: 13, fontWeight: '700' }}>
              {t('switchLanguage')}
            </Text>
          </TouchableOpacity>

          {/* Gold emblem */}
          <View
            style={{
              width: 90,
              height: 90,
              borderRadius: 45,
              backgroundColor: GOLD,
              justifyContent: 'center',
              alignItems: 'center',
              marginBottom: 22,
              ...Platform.select({
                ios: {
                  shadowColor: GOLD,
                  shadowOffset: { width: 0, height: 10 },
                  shadowOpacity: 0.55,
                  shadowRadius: 20,
                },
                android: { elevation: 14 },
              }),
            }}
          >
            <Text
              style={{ fontSize: 32, fontWeight: '900', color: PRIMARY_BLUE, letterSpacing: -1 }}
            >
              CP
            </Text>
          </View>

          <Text
            style={{
              color: '#fff',
              fontSize: 24,
              fontWeight: '900',
              letterSpacing: 0.3,
              textAlign: 'center',
              marginBottom: 6,
              writingDirection: rtl ? 'rtl' : 'ltr',
            }}
          >
            {t('schoolName')}
          </Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <View style={{ width: 20, height: 1, backgroundColor: GOLD }} />
            <Text style={{ color: 'rgba(255,255,255,0.65)', fontSize: 13, letterSpacing: 1 }}>
              {t('subtitle').toUpperCase()}
            </Text>
            <View style={{ width: 20, height: 1, backgroundColor: GOLD }} />
          </View>
        </View>

        {/* Form Card */}
        <View
          style={{
            flex: 1,
            backgroundColor: '#fff',
            marginTop: -26,
            borderTopLeftRadius: 30,
            borderTopRightRadius: 30,
            paddingHorizontal: 28,
            paddingTop: 38,
            paddingBottom: insets.bottom + 32,
          }}
        >
          {/* Welcome text */}
          <Text
            style={{
              fontSize: 24,
              fontWeight: '800',
              color: PRIMARY_BLUE,
              marginBottom: 4,
              textAlign: rtl ? 'right' : 'left',
              writingDirection: rtl ? 'rtl' : 'ltr',
            }}
          >
            {t('welcome')}
          </Text>
          <Text
            style={{
              fontSize: 14,
              color: '#9e9e9e',
              marginBottom: 34,
              textAlign: rtl ? 'right' : 'left',
            }}
          >
            {rtl ? 'الرجاء إدخال بياناتك للمتابعة' : 'Entrez vos identifiants pour continuer'}
          </Text>

          {/* Username field */}
          <View style={{ marginBottom: 16 }}>
            <Text
              style={{
                fontSize: 11,
                fontWeight: '800',
                color: '#757575',
                textTransform: 'uppercase',
                letterSpacing: 1,
                marginBottom: 8,
                textAlign: rtl ? 'right' : 'left',
              }}
            >
              {t('username')}
            </Text>
            <View
              style={{
                flexDirection: rtl ? 'row-reverse' : 'row',
                alignItems: 'center',
                borderWidth: 1.5,
                borderColor: focusedField === 'user' ? GOLD : '#e8e8e8',
                borderRadius: 14,
                backgroundColor: focusedField === 'user' ? '#fffde7' : '#fafafa',
                overflow: 'hidden',
              }}
            >
              <View
                style={{
                  width: 50,
                  height: 54,
                  justifyContent: 'center',
                  alignItems: 'center',
                  backgroundColor: focusedField === 'user' ? `${GOLD}18` : '#f0f0f0',
                }}
              >
                <Text style={{ fontSize: 20 }}>👤</Text>
              </View>
              <TextInput
                style={inputStyle()}
                placeholder={t('username')}
                placeholderTextColor="#bdbdbd"
                value={username}
                onChangeText={setUsername}
                autoCapitalize="none"
                autoCorrect={false}
                onFocus={() => setFocusedField('user')}
                onBlur={() => setFocusedField(null)}
              />
            </View>
          </View>

          {/* Password field */}
          <View style={{ marginBottom: 30 }}>
            <Text
              style={{
                fontSize: 11,
                fontWeight: '800',
                color: '#757575',
                textTransform: 'uppercase',
                letterSpacing: 1,
                marginBottom: 8,
                textAlign: rtl ? 'right' : 'left',
              }}
            >
              {t('password')}
            </Text>
            <View
              style={{
                flexDirection: rtl ? 'row-reverse' : 'row',
                alignItems: 'center',
                borderWidth: 1.5,
                borderColor: focusedField === 'pass' ? GOLD : '#e8e8e8',
                borderRadius: 14,
                backgroundColor: focusedField === 'pass' ? '#fffde7' : '#fafafa',
                overflow: 'hidden',
              }}
            >
              <View
                style={{
                  width: 50,
                  height: 54,
                  justifyContent: 'center',
                  alignItems: 'center',
                  backgroundColor: focusedField === 'pass' ? `${GOLD}18` : '#f0f0f0',
                }}
              >
                <Text style={{ fontSize: 20 }}>🔒</Text>
              </View>
              <TextInput
                style={inputStyle()}
                placeholder={t('password')}
                placeholderTextColor="#bdbdbd"
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                onFocus={() => setFocusedField('pass')}
                onBlur={() => setFocusedField(null)}
              />
            </View>
          </View>

          {/* Login Button */}
          <TouchableOpacity
            style={{
              height: 58,
              backgroundColor: loading ? '#7986cb' : PRIMARY_BLUE,
              borderRadius: 16,
              justifyContent: 'center',
              alignItems: 'center',
              marginBottom: 26,
              ...Platform.select({
                ios: {
                  shadowColor: PRIMARY_BLUE,
                  shadowOffset: { width: 0, height: 8 },
                  shadowOpacity: 0.4,
                  shadowRadius: 14,
                },
                android: { elevation: 10 },
              }),
            }}
            onPress={handleLogin}
            disabled={loading}
            activeOpacity={0.85}
          >
            {loading ? (
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <ActivityIndicator color="#fff" size="small" />
                <Text style={{ color: '#fff', fontSize: 17, fontWeight: '700' }}>
                  {t('loggingIn')}
                </Text>
              </View>
            ) : (
              <Text style={{ color: '#fff', fontSize: 17, fontWeight: '800', letterSpacing: 0.6 }}>
                {t('login')}
              </Text>
            )}
          </TouchableOpacity>

          {/* Divider */}
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 22 }}>
            <View style={{ flex: 1, height: 1, backgroundColor: '#eeeeee' }} />
            <View
              style={{
                width: 8,
                height: 8,
                borderRadius: 4,
                backgroundColor: GOLD,
                marginHorizontal: 12,
              }}
            />
            <View style={{ flex: 1, height: 1, backgroundColor: '#eeeeee' }} />
          </View>

          {/* Demo Credentials */}
          <View
            style={{
              backgroundColor: '#f7f8fc',
              borderRadius: 16,
              padding: 18,
              borderLeftWidth: rtl ? 0 : 4,
              borderRightWidth: rtl ? 4 : 0,
              borderLeftColor: GOLD,
              borderRightColor: GOLD,
            }}
          >
            <Text
              style={{
                fontSize: 10,
                fontWeight: '800',
                color: '#9e9e9e',
                textTransform: 'uppercase',
                letterSpacing: 1.2,
                marginBottom: 12,
                textAlign: rtl ? 'right' : 'left',
              }}
            >
              {rtl ? 'بيانات الدخول التجريبية' : 'Identifiants de démonstration'}
            </Text>

            {/* Admin credential */}
            <View
              style={{
                flexDirection: rtl ? 'row-reverse' : 'row',
                alignItems: 'center',
                marginBottom: 10,
                backgroundColor: '#fff',
                borderRadius: 10,
                padding: 10,
              }}
            >
              <View
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 16,
                  backgroundColor: PRIMARY_BLUE,
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginRight: rtl ? 0 : 10,
                  marginLeft: rtl ? 10 : 0,
                }}
              >
                <Text style={{ color: GOLD, fontSize: 11, fontWeight: '900' }}>م</Text>
              </View>
              <Text
                style={{
                  fontSize: 13,
                  color: '#333',
                  fontWeight: '600',
                  writingDirection: rtl ? 'rtl' : 'ltr',
                }}
              >
                {t('demoAdmin')}
              </Text>
            </View>

            {/* Teacher credential */}
            <View
              style={{
                flexDirection: rtl ? 'row-reverse' : 'row',
                alignItems: 'center',
                backgroundColor: '#fff',
                borderRadius: 10,
                padding: 10,
              }}
            >
              <View
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 16,
                  backgroundColor: '#4caf50',
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginRight: rtl ? 0 : 10,
                  marginLeft: rtl ? 10 : 0,
                }}
              >
                <Text style={{ color: '#fff', fontSize: 11, fontWeight: '900' }}>P</Text>
              </View>
              <Text style={{ fontSize: 13, color: '#333', fontWeight: '600' }}>
                {t('demoTeacher')}
              </Text>
            </View>
          </View>

          {/* Footer */}
          <Text
            style={{
              textAlign: 'center',
              color: '#bdbdbd',
              fontSize: 11,
              marginTop: 28,
              letterSpacing: 0.5,
            }}
          >
            © 2026 Complexe la Providence · Excellence & Discipline
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingAnimatedView>
  );
}
