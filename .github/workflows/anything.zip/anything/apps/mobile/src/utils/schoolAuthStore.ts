import { create } from 'zustand';
import * as SecureStore from 'expo-secure-store';

const SCHOOL_AUTH_KEY = 'cp_school_auth_v1';

export interface SchoolUser {
  username: string;
  role: 'admin' | 'teacher';
  full_name: string;
}

interface SchoolAuthState {
  user: SchoolUser | null;
  isReady: boolean;
  login: (user: SchoolUser) => void;
  logout: () => void;
  loadSession: () => Promise<void>;
}

export const useSchoolAuthStore = create<SchoolAuthState>((set) => ({
  user: null,
  isReady: false,
  login: (user) => {
    SecureStore.setItemAsync(SCHOOL_AUTH_KEY, JSON.stringify(user));
    set({ user });
  },
  logout: () => {
    SecureStore.deleteItemAsync(SCHOOL_AUTH_KEY);
    set({ user: null });
  },
  loadSession: async () => {
    try {
      const stored = await SecureStore.getItemAsync(SCHOOL_AUTH_KEY);
      if (stored) {
        set({ user: JSON.parse(stored) });
      }
    } catch (e) {
      console.error('Failed to load session', e);
    } finally {
      set({ isReady: true });
    }
  },
}));
