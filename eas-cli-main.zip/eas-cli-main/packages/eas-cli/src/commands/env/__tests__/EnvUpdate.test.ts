import chalk from 'chalk';
import * as fs from 'fs-extra';

import { getMockAppFragment, getMockOclifConfig } from '../../../__tests__/commands/utils';
import { DefaultEnvironment } from '../../../build/utils/environment';
import {
  EnvironmentSecretType,
  EnvironmentVariableScope,
  EnvironmentVariableVisibility,
} from '../../../graphql/generated';
import { EnvironmentVariableMutation } from '../../../graphql/mutations/EnvironmentVariableMutation';
import { AppQuery } from '../../../graphql/queries/AppQuery';
import { EnvironmentVariablesQuery } from '../../../graphql/queries/EnvironmentVariablesQuery';
import Log from '../../../log';
import { promptAsync, selectAsync, toggleConfirmAsync } from '../../../prompts';
import {
  parseVisibility,
  promptVariableEnvironmentAsync,
  promptVariableVisibilityAsync,
} from '../../../utils/prompts';
import EnvUpdate from '../update';

jest.mock('../../../graphql/queries/EnvironmentVariablesQuery');
jest.mock('../../../graphql/mutations/EnvironmentVariableMutation');
jest.mock('../../../prompts');
jest.mock('../../../utils/prompts');
jest.mock('../../../graphql/queries/AppQuery');
jest.mock('../../../log');
jest.mock('fs-extra');

describe(EnvUpdate, () => {
  const projectId = 'test-project-id';
  const variableId = '1';
  const graphqlClient = {};
  const mockConfig = getMockOclifConfig();
  const mockContext = {
    privateProjectConfig: { projectId },
    loggedIn: { graphqlClient },
  };

  beforeEach(() => {
    jest.resetAllMocks();
    jest.mocked(AppQuery.byIdAsync).mockImplementation(async () => getMockAppFragment());
    (jest.mocked(promptVariableEnvironmentAsync) as jest.MockedFunction<any>).mockImplementation(
      async (args: any) => {
        if (args.nonInteractive) {
          throw new Error(
            'The `--environment` flag must be set when running in `--non-interactive` mode.'
          );
        }
        if (args.multiple) {
          return ['production'];
        }
        return 'production';
      }
    );
    (jest.mocked(promptVariableVisibilityAsync) as jest.MockedFunction<any>).mockResolvedValue(
      EnvironmentVariableVisibility.Public
    );
    (jest.mocked(parseVisibility) as jest.MockedFunction<any>).mockImplementation(
      (visibility: string) => {
        switch (visibility) {
          case 'plaintext':
            return EnvironmentVariableVisibility.Public;
          case 'sensitive':
            return EnvironmentVariableVisibility.Sensitive;
          case 'secret':
            return EnvironmentVariableVisibility.Secret;
          default:
            throw new Error(`Invalid visibility: ${visibility}`);
        }
      }
    );
    (jest.mocked(selectAsync) as jest.MockedFunction<any>).mockResolvedValue({
      id: variableId,
      name: 'TEST_VARIABLE',
      scope: EnvironmentVariableScope.Project,
    });
  });

  it('updates a project variable by selected name in non-interactive mode', async () => {
    const mockVariables = [
      {
        id: variableId,
        name: 'TEST_VARIABLE',
        scope: EnvironmentVariableScope.Project,
        environments: [DefaultEnvironment.Development],
      },
    ];
    (EnvironmentVariablesQuery.byAppIdAsync as jest.Mock).mockResolvedValue(mockVariables);
    (EnvironmentVariableMutation.updateAsync as jest.Mock).mockResolvedValue(mockVariables[0]);

    const command = new EnvUpdate(
      [
        '--variable-name',
        'TEST_VARIABLE',
        '--variable-environment',
        'development',
        '--non-interactive',
        '--value',
        'new-value',
        '--name',
        'NEW_VARIABLE',
        '--environment',
        'production',
        '--visibility',
        'plaintext',
      ],
      mockConfig
    );
    // @ts-expect-error
    jest.spyOn(command, 'getContextAsync').mockReturnValue(mockContext);
    await command.runAsync();

    expect(EnvironmentVariableMutation.updateAsync).toHaveBeenCalledWith(graphqlClient, {
      id: variableId,
      name: 'NEW_VARIABLE',
      value: 'new-value',
      environments: [DefaultEnvironment.Production],
      visibility: EnvironmentVariableVisibility.Public,
    });
    expect(Log.withTick).toHaveBeenCalledWith(
      `Updated variable ${chalk.bold('TEST_VARIABLE')} on project @testuser/testpp.`
    );
  });

  it('updates an account-wide variable by selected name in non-interactive mode', async () => {
    const mockVariables = [
      {
        id: variableId,
        name: 'TEST_VARIABLE',
        scope: EnvironmentVariableScope.Shared,
        environments: [DefaultEnvironment.Development],
      },
    ];
    (EnvironmentVariablesQuery.sharedAsync as jest.Mock).mockResolvedValue(mockVariables);
    (EnvironmentVariableMutation.updateAsync as jest.Mock).mockResolvedValue(mockVariables[0]);

    const command = new EnvUpdate(
      [
        '--variable-name',
        'TEST_VARIABLE',
        '--variable-environment',
        'development',
        '--non-interactive',
        '--value',
        'new-value',
        '--name',
        'NEW_VARIABLE',
        '--environment',
        'production',
        '--scope',
        'account',
      ],
      mockConfig
    );
    // @ts-expect-error
    jest.spyOn(command, 'getContextAsync').mockReturnValue(mockContext);
    await command.runAsync();

    expect(EnvironmentVariableMutation.updateAsync).toHaveBeenCalledWith(graphqlClient, {
      id: variableId,
      name: 'NEW_VARIABLE',
      value: 'new-value',
      environments: [DefaultEnvironment.Production],
    });
    expect(Log.withTick).toHaveBeenCalledWith(
      `Updated variable ${chalk.bold('TEST_VARIABLE')} on account testuser.`
    );
  });

  it('prompts for variable selection when selected name is not provided', async () => {
    const mockVariables = [
      { id: variableId, name: 'TEST_VARIABLE', scope: EnvironmentVariableScope.Project },
      { id: '2', name: 'ANOTHER_VARIABLE', scope: EnvironmentVariableScope.Project },
    ];
    (EnvironmentVariablesQuery.byAppIdAsync as jest.Mock).mockResolvedValue(mockVariables);
    (EnvironmentVariableMutation.updateAsync as jest.Mock).mockResolvedValue(mockVariables[0]);
    (promptAsync as jest.Mock).mockResolvedValue({ name: mockVariables[0].name });
    (toggleConfirmAsync as jest.Mock).mockResolvedValue(true);

    const command = new EnvUpdate([], mockConfig);
    // @ts-expect-error
    jest.spyOn(command, 'getContextAsync').mockReturnValue(mockContext);
    await command.runAsync();

    expect(selectAsync).toHaveBeenCalled();
    expect(EnvironmentVariableMutation.updateAsync).toHaveBeenCalledWith(
      graphqlClient,
      expect.objectContaining({ id: variableId })
    );
    expect(Log.withTick).toHaveBeenCalledWith(
      `Updated variable ${chalk.bold('TEST_VARIABLE')} on project @testuser/testpp.`
    );
  });

  it('throws an error when variable name is not found', async () => {
    const mockVariables: never[] = [];
    (EnvironmentVariablesQuery.byAppIdAsync as jest.Mock).mockResolvedValue(mockVariables);

    const command = new EnvUpdate(['--variable-name', 'NON_EXISTENT_VARIABLE'], mockConfig);

    // @ts-expect-error
    jest.spyOn(command, 'getContextAsync').mockReturnValue(mockContext);
    await expect(command.runAsync()).rejects.toThrow(
      'Variable with name NON_EXISTENT_VARIABLE  does not exist on project @testuser/testpp.'
    );
  });

  it('accepts development environment when using positional argument', async () => {
    const mockVariable = {
      id: 'var1',
      name: 'TEST_VAR_1',
      value: 'value1',
      environments: [DefaultEnvironment.Development],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      scope: EnvironmentVariableScope.Project,
      visibility: EnvironmentVariableVisibility.Public,
      type: EnvironmentSecretType.String,
    };

    jest.mocked(EnvironmentVariablesQuery.byAppIdAsync).mockResolvedValueOnce([mockVariable]);
    jest.mocked(EnvironmentVariableMutation.updateAsync).mockResolvedValueOnce(mockVariable);
    jest.spyOn(Log, 'log').mockImplementation(() => {});

    const command = new EnvUpdate(
      [
        'development',
        '--variable-name',
        'TEST_VAR_1',
        '--value',
        'new-value',
        '--scope',
        'project',
        '--non-interactive',
      ],
      mockConfig
    );

    // @ts-expect-error
    jest.spyOn(command, 'getContextAsync').mockReturnValue({
      loggedIn: { graphqlClient },
      projectId,
    });

    await command.runAsync();

    expect(EnvironmentVariablesQuery.byAppIdAsync).toHaveBeenCalledWith(graphqlClient, {
      appId: projectId,
      environment: DefaultEnvironment.Development,
      filterNames: ['TEST_VAR_1'],
    });
  });

  it('processes file type variable in non-interactive mode with --type file and --value', async () => {
    const testFilePath = '/path/to/test-file.json';
    const testFileBase64 = 'dGVzdCBmaWxlIGNvbnRlbnQ=';
    const testFileName = 'test-file.json';

    const mockVariable = {
      id: variableId,
      name: 'TEST_VARIABLE',
      scope: EnvironmentVariableScope.Project,
      environments: [DefaultEnvironment.Development],
      type: EnvironmentSecretType.String,
    };

    const mockUpdatedVariable = {
      ...mockVariable,
      type: EnvironmentSecretType.FileBase64,
    };

    (EnvironmentVariablesQuery.byAppIdAsync as jest.Mock).mockResolvedValue([mockVariable]);
    (EnvironmentVariableMutation.updateAsync as jest.Mock).mockResolvedValue(mockUpdatedVariable);

    // Mock fs.pathExists to return true
    jest.mocked(fs.pathExists).mockImplementation(() => Promise.resolve(true));
    // Mock fs.readFile to return base64 encoded content
    jest.mocked(fs.readFile).mockImplementation(() => Promise.resolve(testFileBase64));

    const command = new EnvUpdate(
      [
        '--variable-name',
        'TEST_VARIABLE',
        '--variable-environment',
        'development',
        '--non-interactive',
        '--type',
        'file',
        '--value',
        testFilePath,
        '--environment',
        'production',
      ],
      mockConfig
    );
    // @ts-expect-error
    jest.spyOn(command, 'getContextAsync').mockReturnValue(mockContext);
    await command.runAsync();

    // Verify file was checked for existence
    expect(fs.pathExists).toHaveBeenCalledWith(testFilePath);
    // Verify file was read as base64
    expect(fs.readFile).toHaveBeenCalledWith(testFilePath, 'base64');

    // Verify update was called with FileBase64 type and base64-encoded value
    expect(EnvironmentVariableMutation.updateAsync).toHaveBeenCalledWith(graphqlClient, {
      id: variableId,
      value: testFileBase64,
      environments: [DefaultEnvironment.Production],
      type: EnvironmentSecretType.FileBase64,
      fileName: testFileName,
    });
  });

  it('throws error when updating FILE type variable with value that is not a valid file path', async () => {
    const plainStringValue = 'some-new-value';

    const mockVariable = {
      id: variableId,
      name: 'TEST_VARIABLE',
      scope: EnvironmentVariableScope.Project,
      environments: [DefaultEnvironment.Development],
      type: EnvironmentSecretType.FileBase64,
    };

    (EnvironmentVariablesQuery.byAppIdAsync as jest.Mock).mockResolvedValue([mockVariable]);

    // Mock fs.pathExists to return false (file doesn't exist)
    jest.mocked(fs.pathExists).mockImplementation(() => Promise.resolve(false));

    const command = new EnvUpdate(
      [
        '--variable-name',
        'TEST_VARIABLE',
        '--variable-environment',
        'development',
        '--non-interactive',
        '--value',
        plainStringValue,
        '--environment',
        'production',
        // Note: --type is NOT specified
      ],
      mockConfig
    );
    // @ts-expect-error
    jest.spyOn(command, 'getContextAsync').mockReturnValue(mockContext);

    // Should throw error when FILE type variable is updated with non-file value
    await expect(command.runAsync()).rejects.toThrow(
      `Variable "TEST_VARIABLE" is a file type, but "${plainStringValue}" does not exist as a file. If you want to convert it to a string, pass --type string.`
    );
  });

  it('throws error when --type file is explicitly specified but file does not exist', async () => {
    const nonExistentFilePath = '/path/to/nonexistent-file.json';

    const mockVariable = {
      id: variableId,
      name: 'TEST_VARIABLE',
      scope: EnvironmentVariableScope.Project,
      environments: [DefaultEnvironment.Development],
      type: EnvironmentSecretType.String,
    };

    (EnvironmentVariablesQuery.byAppIdAsync as jest.Mock).mockResolvedValue([mockVariable]);

    // Mock fs.pathExists to return false (file doesn't exist)
    jest.mocked(fs.pathExists).mockImplementation(() => Promise.resolve(false));

    const command = new EnvUpdate(
      [
        '--variable-name',
        'TEST_VARIABLE',
        '--variable-environment',
        'development',
        '--non-interactive',
        '--type',
        'file',
        '--value',
        nonExistentFilePath,
        '--environment',
        'production',
      ],
      mockConfig
    );
    // @ts-expect-error
    jest.spyOn(command, 'getContextAsync').mockReturnValue(mockContext);

    // Should throw error when --type file is explicitly specified
    await expect(command.runAsync()).rejects.toThrow(
      `File "${nonExistentFilePath}" does not exist`
    );
  });

  it('preserves existing STRING type when updating value without --type flag', async () => {
    const stringValue = 'my-best-file.json';

    const mockVariable = {
      id: variableId,
      name: 'MY_VAR',
      scope: EnvironmentVariableScope.Project,
      environments: [DefaultEnvironment.Development],
      type: EnvironmentSecretType.String,
      value: 'old-value',
      visibility: EnvironmentVariableVisibility.Public,
    };

    const mockUpdatedVariable = {
      ...mockVariable,
      value: stringValue,
    };

    (EnvironmentVariablesQuery.byAppIdAsync as jest.Mock).mockResolvedValue([mockVariable]);
    (EnvironmentVariableMutation.updateAsync as jest.Mock).mockResolvedValue(mockUpdatedVariable);

    const command = new EnvUpdate(
      [
        '--variable-name',
        'MY_VAR',
        '--variable-environment',
        'development',
        '--non-interactive',
        '--value',
        stringValue,
        // Note: --type is NOT specified
      ],
      mockConfig
    );
    // @ts-expect-error
    jest.spyOn(command, 'getContextAsync').mockReturnValue(mockContext);
    await command.runAsync();

    // Verify update was called with preserved STRING type
    expect(EnvironmentVariableMutation.updateAsync).toHaveBeenCalledWith(graphqlClient, {
      id: variableId,
      value: stringValue,
      type: EnvironmentSecretType.String,
    });
  });

  it('preserves existing FILE type when updating value without --type flag', async () => {
    const testFilePath = '/path/to/test-file.json';
    const testFileBase64 = 'dGVzdCBmaWxlIGNvbnRlbnQ=';
    const testFileName = 'test-file.json';

    const mockVariable = {
      id: variableId,
      name: 'MY_FILE_VAR',
      scope: EnvironmentVariableScope.Project,
      environments: [DefaultEnvironment.Development],
      type: EnvironmentSecretType.FileBase64,
      value: 'old-base64-value',
      visibility: EnvironmentVariableVisibility.Public,
    };

    const mockUpdatedVariable = {
      ...mockVariable,
      value: testFileBase64,
    };

    (EnvironmentVariablesQuery.byAppIdAsync as jest.Mock).mockResolvedValue([mockVariable]);
    (EnvironmentVariableMutation.updateAsync as jest.Mock).mockResolvedValue(mockUpdatedVariable);

    // Mock fs.pathExists to return true
    jest.mocked(fs.pathExists).mockImplementation(() => Promise.resolve(true));
    // Mock fs.readFile to return base64 encoded content
    jest.mocked(fs.readFile).mockImplementation(() => Promise.resolve(testFileBase64));

    const command = new EnvUpdate(
      [
        '--variable-name',
        'MY_FILE_VAR',
        '--variable-environment',
        'development',
        '--non-interactive',
        '--value',
        testFilePath,
        // Note: --type is NOT specified
      ],
      mockConfig
    );
    // @ts-expect-error
    jest.spyOn(command, 'getContextAsync').mockReturnValue(mockContext);
    await command.runAsync();

    // Verify file was checked for existence
    expect(fs.pathExists).toHaveBeenCalledWith(testFilePath);
    // Verify file was read as base64
    expect(fs.readFile).toHaveBeenCalledWith(testFilePath, 'base64');

    // Verify update was called with preserved FILE type
    expect(EnvironmentVariableMutation.updateAsync).toHaveBeenCalledWith(graphqlClient, {
      id: variableId,
      value: testFileBase64,
      type: EnvironmentSecretType.FileBase64,
      fileName: testFileName,
    });
  });
});
