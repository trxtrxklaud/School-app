export default jest.fn(() => ({}));
