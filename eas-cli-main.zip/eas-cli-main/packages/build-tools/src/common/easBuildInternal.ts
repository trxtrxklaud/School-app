import {
  BuildJob,
  Env,
  Ios,
  Metadata,
  Platform,
  sanitizeBuildJob,
  sanitizeMetadata,
} from '@expo/eas-build-job';
import { PipeMode, bunyan } from '@expo/logger';
import { BuildStepEnv } from '@expo/steps';
import spawn from '@expo/turtle-spawn';
import assert from 'assert';
import Joi from 'joi';
import nullthrows from 'nullthrows';

import { BuildContext } from '../context';
import { resolveEasCommandPrefixAndEnvAsync } from '../utils/easCli';

const EasBuildInternalResultSchema = Joi.object<{ job: object; metadata: object }>({
  job: Joi.object().unknown(),
  metadata: Joi.object().unknown(),
});

export async function runEasBuildInternalAsync<TJob extends BuildJob>({
  job,
  logger,
  env,
  cwd,
  projectRootOverride,
}: {
  job: TJob;
  logger: bunyan;
  env: BuildStepEnv;
  cwd: string;
  projectRootOverride?: string;
}): Promise<{
  newJob: TJob;
  newMetadata: Metadata;
}> {
  const { cmd, args, extraEnv } = await resolveEasCommandPrefixAndEnvAsync();
  const { buildProfile, githubTriggerOptions } = job;
  assert(buildProfile, 'build profile is missing in a build from git-based integration.');

  const autoSubmitArgs = [];
  if (githubTriggerOptions?.submitProfile) {
    autoSubmitArgs.push('--auto-submit-with-profile');
    autoSubmitArgs.push(githubTriggerOptions.submitProfile);
  } else if (githubTriggerOptions?.autoSubmit) {
    autoSubmitArgs.push('--auto-submit');
  }

  const refreshAdHocProvisioningProfileArgs = [];
  if (job.platform === Platform.IOS && job.refreshAdHocProvisioningProfile === true) {
    refreshAdHocProvisioningProfileArgs.push('--refresh-ad-hoc-provisioning-profile');
  }

  try {
    const result = await spawn(
      cmd,
      [
        ...args,
        'build:internal',
        '--platform',
        job.platform,
        '--profile',
        buildProfile,
        ...autoSubmitArgs,
        ...refreshAdHocProvisioningProfileArgs,
      ],
      {
        cwd,
        env: {
          ...env,
          EXPO_TOKEN: nullthrows(job.secrets, 'Secrets must be defined for non-custom builds')
            .robotAccessToken,
          ...extraEnv,
          EAS_PROJECT_ROOT: projectRootOverride,
        },
        logger,
        // This prevents printing stdout with job secrets and credentials to logs.
        mode: PipeMode.STDERR_ONLY_AS_STDOUT,
      }
    );

    const stdout = result.stdout.toString();
    const parsed = JSON.parse(stdout);
    return validateEasBuildInternalResult({
      result: parsed,
      oldJob: job,
    });
  } catch (err: any) {
    throw new Error('Failed to run eas build:internal');
  }
}

export async function resolveEnvFromBuildProfileAsync<TJob extends BuildJob>(
  ctx: BuildContext<TJob>,
  { cwd }: { cwd: string }
): Promise<Env> {
  const { cmd, args, extraEnv } = await resolveEasCommandPrefixAndEnvAsync();
  const { buildProfile } = ctx.job;
  assert(buildProfile, 'build profile is missing in a build from git-based integration.');
  let spawnResult;
  try {
    spawnResult = await spawn(
      cmd,
      [
        ...args,
        'config',
        '--platform',
        ctx.job.platform,
        '--profile',
        buildProfile,
        '--non-interactive',
        '--json',
        '--eas-json-only',
      ],
      {
        cwd,
        env: { ...ctx.env, ...extraEnv },
      }
    );
  } catch (err: any) {
    ctx.logger.error(`Failed to the read build profile ${buildProfile} from eas.json.`);
    ctx.logger.error(err.stderr?.toString());
    throw Error(`Failed to read the build profile ${buildProfile} from eas.json.`);
  }
  const stdout = spawnResult.stdout.toString();
  const parsed = JSON.parse(stdout);
  const env = validateEnvs(parsed.buildProfile);
  return env;
}

function validateEasBuildInternalResult<TJob extends BuildJob>({
  oldJob,
  result,
}: {
  oldJob: TJob;
  result: any;
}): { newJob: TJob; newMetadata: Metadata } {
  const { value, error } = EasBuildInternalResultSchema.validate(result, {
    stripUnknown: true,
    convert: true,
    abortEarly: false,
  });
  if (error) {
    throw error;
  }
  const newJob = sanitizeBuildJob({
    ...value.job,
    // We want to retain values that we have set on the job.
    appId: oldJob.appId,
    initiatingUserId: oldJob.initiatingUserId,
    ...(oldJob.platform === Platform.IOS && oldJob.refreshAdHocProvisioningProfile === true
      ? { refreshAdHocProvisioningProfile: true }
      : null),
  }) as TJob;
  assert(newJob.platform === oldJob.platform, 'eas-cli returned a job for a wrong platform');
  const newMetadata = sanitizeMetadata(value.metadata);
  return { newJob, newMetadata };
}

function validateEnvs(result: any): Env {
  const { value, error } = Joi.object({
    env: Joi.object().pattern(Joi.string(), Joi.string()),
  }).validate(result, {
    stripUnknown: true,
    convert: true,
    abortEarly: false,
  });
  if (error) {
    throw error;
  }
  return value?.env;
}
