import { Android, BuildJob, Ios, Platform } from '@expo/eas-build-job';
import { PipeMode } from '@expo/logger';
import { asyncResult } from '@expo/results';
import fs from 'fs-extra';
import os from 'os';
import path from 'path';
import StreamZip from 'node-stream-zip';

import { findArtifacts } from './artifacts';
import { runEasCliCommand } from './easCli';
import { resolveArtifactPath } from '../ios/resolve';
import { BuildContext } from '../context';
import { isEASUpdateConfigured } from './expoUpdates';

export async function uploadEmbeddedBundleAsync(ctx: BuildContext<BuildJob>): Promise<void> {
  if (!(await isEASUpdateConfigured(ctx))) {
    ctx.markBuildPhaseSkipped();
    return;
  }

  const { platform } = ctx.job;
  if (platform === Platform.IOS && (ctx.job as Ios.Job).simulator) {
    ctx.markBuildPhaseSkipped();
    return;
  }

  const channel = ctx.job.updates?.channel;
  if (!channel) {
    ctx.logger.warn(
      'Skipping embedded bundle upload: no channel configured for this build profile.'
    );
    ctx.markBuildPhaseHasWarnings();
    return;
  }

  const projectDir = ctx.getReactNativeProjectDirectory();

  let archivePattern: string;
  if (platform === Platform.IOS) {
    archivePattern = resolveArtifactPath(ctx as BuildContext<Ios.Job>);
  } else if (platform === Platform.ANDROID) {
    archivePattern =
      (ctx as BuildContext<Android.Job>).job.applicationArchivePath ??
      'android/app/build/outputs/**/*.{apk,aab}';
  } else {
    throw new Error(`Uploading embedded updates is not supported for the ${platform} platform.`);
  }

  const [archivePath] = await findArtifacts({
    rootDir: projectDir,
    patternOrPath: archivePattern,
    logger: null,
  }).catch(() => [] as string[]);

  if (!archivePath) {
    ctx.logger.warn('Skipping embedded bundle upload: build archive not found.');
    ctx.markBuildPhaseHasWarnings();
    return;
  }

  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'eas-embedded-bundle-'));
  const bundleName = platform === Platform.IOS ? 'main.jsbundle' : 'index.android.bundle';
  const bundlePath = path.join(tmpDir, bundleName);
  const manifestPath = path.join(tmpDir, 'app.manifest');
  const zip = new StreamZip.async({ file: archivePath });
  try {
    const entries = Object.values(await zip.entries());
    const bundleEntry = entries.find(e =>
      platform === Platform.IOS
        ? e.name.endsWith('/main.jsbundle')
        : e.name.endsWith('assets/index.android.bundle')
    );
    const manifestEntry = entries.find(e =>
      platform === Platform.IOS
        ? e.name.includes('EXUpdates.bundle/app.manifest')
        : e.name.endsWith('assets/app.manifest')
    );

    if (!bundleEntry || !manifestEntry) {
      ctx.logger.warn('Skipping embedded bundle upload: bundle or manifest not found in archive.');
      ctx.markBuildPhaseHasWarnings();
      return;
    }

    await zip.extract(bundleEntry.name, bundlePath);
    await zip.extract(manifestEntry.name, manifestPath);

    const args = [
      'update:embedded:upload',
      '--platform',
      platform,
      '--bundle',
      bundlePath,
      '--manifest',
      manifestPath,
      '--channel',
      channel,
      '--non-interactive',
    ];
    if (ctx.env.EAS_BUILD_ID) {
      args.push('--build-id', ctx.env.EAS_BUILD_ID);
    }
    await runEasCliCommand({
      args,
      options: {
        cwd: projectDir,
        env: ctx.env,
        logger: ctx.logger,
        mode: PipeMode.STDERR_ONLY_AS_STDOUT,
      },
    });
  } catch (err: any) {
    ctx.logger.warn({ err }, 'Failed to upload embedded bundle.');
    ctx.markBuildPhaseHasWarnings();
  } finally {
    await asyncResult(zip.close());
  }
}
