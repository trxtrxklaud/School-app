import { Ios, UserError } from '@expo/eas-build-job';
import { BuildFunction, BuildStepInput, BuildStepInputValueTypeName } from '@expo/steps';
import assert from 'assert';
import semver from 'semver';
import { z } from 'zod';

import { updateVersionsAsync } from '../utils/ios/configure';
import { IosBuildCredentialsSchema } from '../utils/ios/credentials/credentials';
import IosCredentialsManager from '../utils/ios/credentials/manager';
import { resolveBuildConfiguration } from '../utils/ios/resolve';

export function configureIosVersionFunction(): BuildFunction {
  return new BuildFunction({
    namespace: 'eas',
    id: 'configure_ios_version',
    name: 'Configure iOS version',
    __metricsId: 'eas/configure_ios_version',
    inputProviders: [
      BuildStepInput.createProvider({
        id: 'credentials',
        required: false,
        allowedValueTypeName: BuildStepInputValueTypeName.JSON,
        defaultValue: '${ eas.job.secrets.buildCredentials }',
      }),
      BuildStepInput.createProvider({
        id: 'target_names',
        required: false,
        allowedValueTypeName: BuildStepInputValueTypeName.JSON,
      }),
      BuildStepInput.createProvider({
        id: 'build_configuration',
        required: false,
        allowedValueTypeName: BuildStepInputValueTypeName.STRING,
      }),
      BuildStepInput.createProvider({
        id: 'build_number',
        required: false,
        allowedValueTypeName: BuildStepInputValueTypeName.STRING,
      }),
      BuildStepInput.createProvider({
        id: 'app_version',
        required: false,
        allowedValueTypeName: BuildStepInputValueTypeName.STRING,
      }),
    ],
    fn: async (stepCtx, { inputs }) => {
      assert(stepCtx.global.staticContext.job, 'Job is not defined');
      const job = stepCtx.global.staticContext.job as Ios.Job;

      const buildNumber =
        (inputs.build_number.value as string | undefined) ?? job.version?.buildNumber;
      const appVersion =
        (inputs.app_version.value as string | undefined) ?? job.version?.appVersion;
      if (appVersion && !semver.valid(appVersion)) {
        throw new UserError(
          'EAS_CONFIGURE_IOS_VERSION_INVALID_APP_VERSION',
          `App version provided by the "app_version" input is not a valid semver version: ${appVersion}`
        );
      }

      if (!buildNumber && !appVersion) {
        stepCtx.logger.info(
          'No build number or app version provided. Skipping the step to configure iOS version.'
        );
        return;
      }

      const targetNamesInput = inputs.target_names.value;
      let targetNames: string[];
      if (targetNamesInput !== undefined) {
        const parsed = z.array(z.string()).safeParse(targetNamesInput);
        if (!parsed.success) {
          throw new UserError(
            'EAS_CONFIGURE_IOS_VERSION_INVALID_TARGET_NAMES',
            '"target_names" input must be an array of strings.',
            { cause: parsed.error }
          );
        }
        targetNames = parsed.data;
      } else {
        const { value, error } = IosBuildCredentialsSchema.validate(inputs.credentials.value, {
          stripUnknown: true,
          convert: true,
          abortEarly: false,
        });
        if (error) {
          throw error;
        }

        const credentialsManager = new IosCredentialsManager(value);
        const credentials = await credentialsManager.prepare(stepCtx.logger);
        targetNames = Object.keys(credentials.targetProvisioningProfiles);
      }

      stepCtx.logger.info('Setting iOS version...');
      if (buildNumber) {
        stepCtx.logger.info(`Build number: ${buildNumber}`);
      }
      if (appVersion) {
        stepCtx.logger.info(`App version: ${appVersion}`);
      }

      await updateVersionsAsync(
        stepCtx.logger,
        stepCtx.workingDirectory,
        {
          buildNumber,
          appVersion,
        },
        {
          targetNames,
          buildConfiguration: resolveBuildConfiguration(
            job,
            inputs.build_configuration.value as string | undefined
          ),
        }
      );
    },
  });
}
