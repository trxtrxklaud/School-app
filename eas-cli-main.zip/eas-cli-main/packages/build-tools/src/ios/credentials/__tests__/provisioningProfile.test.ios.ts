import { Ios } from '@expo/eas-build-job';
import { createLogger } from '@expo/logger';
import crypto from 'crypto';

import { provisioningProfile } from './fixtures';
import { BuildContext } from '../../../context';
import Keychain from '../keychain';
import ProvisioningProfile from '../provisioningProfile';

const mockLogger = createLogger({ name: 'mock-logger' });

jest.setTimeout(60 * 1000);

// Those are in fact "real" tests in that they really execute the `fastlane` commands.
// We need the JS code to modify the file system, so we need to mock it.
jest.unmock('fs');

describe('ProvisioningProfile class', () => {
  describe('verifyCertificate method', () => {
    let ctx: BuildContext<Ios.Job>;
    let keychain: Keychain<Ios.Job>;

    beforeAll(async () => {
      ctx = new BuildContext({ projectRootDirectory: '.' } as Ios.Job, {
        workingdir: '/workingdir',
        logBuffer: { getLogs: () => [], getPhaseLogs: () => [] },
        logger: mockLogger,
        env: {
          __API_SERVER_URL: 'http://api.expo.test',
        },
        uploadArtifact: jest.fn(),
      });
      keychain = new Keychain(ctx);
      await keychain.create();
    });

    afterAll(async () => {
      await keychain.destroy();
    });

    it("shouldn't throw any error if the provisioning profile and distribution certificate match", async () => {
      const pp = new ProvisioningProfile(
        ctx,
        Buffer.from(provisioningProfile.dataBase64, 'base64'),
        keychain.data.path,
        'testapp',
        'Abc 123'
      );
      try {
        await pp.init();
        expect(() => {
          pp.verifyCertificate(provisioningProfile.certFingerprint);
        }).not.toThrow();
      } finally {
        await pp.destroy();
      }
    });

    it("should throw an error if the provisioning profile and distribution certificate don't match", async () => {
      const pp = new ProvisioningProfile(
        ctx,
        Buffer.from(provisioningProfile.dataBase64, 'base64'),
        keychain.data.path,
        'testapp',
        'Abc 123'
      );

      try {
        await pp.init();
        expect(() => {
          pp.verifyCertificate('2137');
        }).toThrowError(/don't match/);
      } finally {
        await pp.destroy();
      }
    });

    it('should match a certificate that is not at index 0 in DeveloperCertificates', async () => {
      const pp = new ProvisioningProfile(
        ctx,
        Buffer.from(provisioningProfile.dataBase64, 'base64'),
        keychain.data.path,
        'testapp',
        'Abc 123'
      );

      try {
        await pp.init();

        // Prepend an unrelated certificate so the real one moves to index 1
        const dummyCert = Buffer.from('dummy-certificate-data');
        (pp as any).developerCertificates = [dummyCert, ...(pp as any).developerCertificates];

        // The original cert fingerprint should still match
        expect(() => {
          pp.verifyCertificate(provisioningProfile.certFingerprint);
        }).not.toThrow();

        // A non-matching fingerprint should still fail
        expect(() => {
          pp.verifyCertificate('2137');
        }).toThrowError(/don't match/);

        // The dummy cert's fingerprint should also match
        const dummyFingerprint = crypto
          .createHash('sha1')
          .update(new Uint8Array(dummyCert))
          .digest('hex')
          .toUpperCase();
        expect(() => {
          pp.verifyCertificate(dummyFingerprint);
        }).not.toThrow();
      } finally {
        await pp.destroy();
      }
    });
  });
});
